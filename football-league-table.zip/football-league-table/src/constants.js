const AppConstants = {
    METHOD_GET: 'GET',
    GET_FOOTBALL_DATA: 'get_football_data',
    API_REQUEST: 'api_request',
    API_SUCCESS: 'api_success',
    API_FAILURE: 'api_failure',
};

export default AppConstants;